package com.lms.testCases;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;

import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.lms.utilities.browserFactory;
import com.lms.utilities.configDataProvider;
import com.lms.utilities.elementAction;
import com.lms.utilities.elementActions;
import com.lms.utilities.elementWait;
import com.lms.utilities.excelDataProvider;
import com.lms.utilities.helper;

public class baseClass {
	public static WebDriver driver;
	public static excelDataProvider objExcl;
	public static configDataProvider objConfig;
	public static ExtentReports report;
	public static ExtentTest logger;
	public static  elementAction eleAct;
	public static elementActions elementAct;
	public static elementWait wait;
	boolean Testskip = false;
	int counter = 1;
	int retryLimit = 1;
	public static boolean extentRptflag=true;
	public static String LMSAcName;
	
	@BeforeSuite
	public void setUpSuite() throws IOException
	{
		Reporter.log("Setting up reports and test getting started.",true);
		objExcl=new excelDataProvider();
		objConfig=new configDataProvider();
		
		ExtentSparkReporter extent= new ExtentSparkReporter(new File(System.getProperty("user.dir")+"/Reports/LMS_"+helper.getCurrentDateTime()+".html")); 
		report=new ExtentReports();
		report.attachReporter(extent);		
		InetAddress inetAddress = InetAddress.getLocalHost();
		report.setSystemInfo("OS", "Windows");
		report.setSystemInfo("Type of Testing", "Automation");
		report.setSystemInfo("Host IP", inetAddress.toString());
		report.setSystemInfo("User Name", System.getProperty("user.name"));
		report.setSystemInfo("Environment", "QA");
		report.setSystemInfo("Server", objConfig.getURL());
		extent.loadXMLConfig(new File(System.getProperty("user.dir")+"/XMLFiles/extent-config.xml"));
		Reporter.log("Extent Report has been configured.");
	}
	
	//@Parameters({"browser","URLtoBeTest"})
	@BeforeTest
	//public void setup(String exBrowser, String URL)
	public void setup() throws InterruptedException
	{
		Reporter.log("Trying to start browser and getting application ready",true);
		driver=browserFactory.startApplication(driver, objConfig.getBrowser(), objConfig.getURL());
		Reporter.log("driver is initiated..",true);
		eleAct=new elementAction(driver);
		elementAct=new elementActions(driver);
		wait=new elementWait();
		Reporter.log("element class is initiated...",true);
		//driver=browserFactory.startApplication(driver, exBrowser, URL);
		Reporter.log("Browser and application is up and running.",true);
		//Log.info("Browser and application is up and running.");
	}
	
	@AfterSuite
	public void tearDown()
	{
		//browserFactory.QuitBrowser(driver);
	}
	
	@BeforeMethod
	public void startMethod() {
		wait.applyImplicitWait();	
	}

	@AfterMethod
	public void tearDownMethod(ITestResult result) throws IOException
	{
		if(result.getStatus()==ITestResult.FAILURE)
		{
			
			logger.fail(result.getThrowable());
			logger.fail("Test Failed", MediaEntityBuilder.createScreenCaptureFromPath(helper.CaptureScreenShot(driver,result.getMethod().getMethodName())).build());
		}
		
		else if(result.getStatus()==ITestResult.SUCCESS)
		{
			//logger.pass("Test Passed");
			
			logger.pass("Test Passed", MediaEntityBuilder.createScreenCaptureFromPath(helper.CaptureScreenShot(driver,result.getMethod().getMethodName())).build());
	 	}	
		report.flush();
	}
}
