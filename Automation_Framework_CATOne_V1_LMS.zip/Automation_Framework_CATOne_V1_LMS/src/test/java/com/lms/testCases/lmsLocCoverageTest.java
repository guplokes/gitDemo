package com.lms.testCases;

import java.awt.AWTException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.lms.pages.locationCoveragesPage;
import com.lms.pages.locationMasterPage;

public class lmsLocCoverageTest extends baseClass {
	static locationCoveragesPage objLC;
	
	@DataProvider(name = "LocationCoverage")
	public static Object[][] readLocationCoverageData() throws Exception 
	{
		locationMasterPage	objLM =new locationMasterPage();
		objLM.clickLocMasterTab();
		Thread.sleep(5000);
		
		objLC =new locationCoveragesPage(driver);
		objLC.clickLocCovTab();
		Thread.sleep(5000);
		Thread.sleep(5000);
		
		if (extentRptflag) {
			logger = report.createTest("Add Location Coverage in the account.");
		}
		
		return objExcl.readExcelSheet("Location Coverage");
	}
	
	@Test(priority = 18, dataProvider = "LocationCoverage")
	public void addLocationDataonLMS(String locID, String BuildTIV1,String BuildTIV2,String BuildTIV3,String ContTIV1,
			String ContTIV2,String ContTIV3,String Damagebility1, String Damagebility2, String	Damagebility3, String	OtherTIV1,
			String OtherTIV2, String OtherTIV3,	String BITIV1, String BITIV2, String BITIV3, String	BIPOI1, String	BIPOI2,
			String BIPOI3, String WaitingPeriod) throws InterruptedException, AWTException {
		
		objLC.updateLocCoverages(locID, BuildTIV1,BuildTIV2, BuildTIV3, ContTIV1, ContTIV2, ContTIV3, Damagebility1, Damagebility2,
				Damagebility3,OtherTIV1, OtherTIV2,  OtherTIV3,	 BITIV1,  BITIV2,  BITIV3, 	BIPOI1, BIPOI2,BIPOI3,  WaitingPeriod);
		//objLC.addCovDatailofPeril();
		//objLC.deleteCovDatailofPeril();
	}
}
