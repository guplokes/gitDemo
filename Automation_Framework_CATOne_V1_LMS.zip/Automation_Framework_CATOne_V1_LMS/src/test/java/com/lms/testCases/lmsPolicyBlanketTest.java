package com.lms.testCases;

import java.awt.AWTException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.lms.pages.policyBlanketDetailsPage;

public class lmsPolicyBlanketTest extends baseClass {
	policyBlanketDetailsPage objPBD;
	
	@DataProvider(name = "PolicyBlanketData")
	public static Object[][] readPolicyBlanketDetails() throws Exception 
	{
		if (extentRptflag) {
			logger = report.createTest("Add Policy Blanket Data in a report");
		}
		return objExcl.readExcelSheet("Policy Blanket Data");
	}
	
	@Test(priority = 10, dataProvider = "PolicyBlanketData")
	public void AddPolicyBlanketData(String Peril,String dedCode, String dedType, String dedBasis, String blanketDed, 
			String maxDed, String minDed, String limitCode, String limitType, String limitBasis, String limitAmt) throws InterruptedException, AWTException {
			
		//Go to Policy Blanket Tab
		objPBD = new policyBlanketDetailsPage();
		objPBD.clickPolicyBlanketTab();
		
		objPBD.addBlanketData(Peril, dedCode, dedType, dedBasis, blanketDed, maxDed, minDed, limitCode, limitType, limitBasis,  limitAmt);
	}
	
	//@Test(priority = 11)
	public void deletePolicyBlanket() throws InterruptedException, AWTException {
		if (extentRptflag) {
			logger = report.createTest("Delete Policy Blanket Data in a report");
		}
		objPBD.deleteBlanketDetails();
	}

}
