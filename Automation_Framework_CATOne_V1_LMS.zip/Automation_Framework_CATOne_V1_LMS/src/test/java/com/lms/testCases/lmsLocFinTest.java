package com.lms.testCases;

import java.awt.AWTException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.lms.pages.locationFinancialPage;

public class lmsLocFinTest extends baseClass {
	static locationFinancialPage objLF;
	
	@DataProvider(name = "LocationFinancial")
	public static Object[][] readLocationCoverageData() throws Exception 
	{
		Thread.sleep(5000);
		objLF =new locationFinancialPage();
		objLF.clickTabLocMaster();
		objLF.clickTabLocFinancial();
		
		if (extentRptflag) {
			logger = report.createTest("Modify Location Financial in the account.");
		}
		
		return objExcl.readExcelSheet("Location Financial");
	}
	
	
	@Test(priority = 19, dataProvider = "LocationFinancial")
	public void addLocationfinancial(String peril, String covType, String locNum, String lmtType, String lmt, 
			String dedType, String ded, String minDed, String maxDed) throws InterruptedException, AWTException {
		
		objLF.updateLocFinDetails( peril,  covType,  locNum,  lmtType,  lmt, dedType,  ded,  minDed,  maxDed);
	}
}
