package com.lms.testCases;

import java.awt.AWTException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.lms.pages.perilLvlFinDetailsPage;

public class lmsPerilLvlFinTest extends baseClass {
	
	perilLvlFinDetailsPage objPLFD;
	
	
	@DataProvider(name = "LocationGroupData")
	public Object[][] readLocationGroupData() throws Exception 
	{
		if (extentRptflag) {
			logger = report.createTest("Add a Location Group");
		}
		
		return objExcl.readExcelSheet("Location Group Data");
	}
	
	@Test(priority = 11, dataProvider = "LocationGroupData")
	public void addLocationGroup(String locGrpName, String fieldName, String Operator, String value, String conOpr) 
			throws InterruptedException, AWTException {
		
		objPLFD =new perilLvlFinDetailsPage();
		objPLFD.clickPerilLvlFinTab();
		
		objPLFD.addLocationGroup(locGrpName, fieldName,  Operator, value, conOpr);
	}
	
	
	@DataProvider(name = "PerilLevelFinancialData")
	public Object[][] readPolicyBlanketDetails() throws Exception 
	{
		if (extentRptflag) {
			logger = report.createTest("Add Peril Financial Data in a report");
		}
		
		return objExcl.readExcelSheet("Peril Level Financial Data");
	}
	
	@Test(priority = 12, dataProvider = "PerilLevelFinancialData")
	public void addPerilLevelFinData(String perilName, String logGrpName, String layerName, String limitCode, String limitBasis, String limitType, String sublimit,
			String sublimitPart, String sublimitAttachment, String deductible, String dedCode, String dedType, String dedBasis,
			String minDed, String maxDed) throws InterruptedException, AWTException {
		
		objPLFD.addLocationFinancialData(perilName, logGrpName, layerName, limitCode, limitBasis, limitType, sublimit,
			 sublimitPart, sublimitAttachment, deductible, dedCode, dedType, dedBasis, minDed, maxDed);
		
	}
	
	//@Test(priority = 13)
	public void filterPerilFinancial() throws InterruptedException, AWTException {
		
		if (extentRptflag) {
			logger = report.createTest("Filter Peril Financial Data in a report");
		}
		objPLFD.applyFilter();	
	}
	
	//@Test(priority = 14)
	public void updatePerilFinancial() throws InterruptedException, AWTException {
		if (extentRptflag) {
			logger = report.createTest("Update Peril Financial Data in a report");
		}
		objPLFD.bulkUpdatePerilFin();	
	}
}
