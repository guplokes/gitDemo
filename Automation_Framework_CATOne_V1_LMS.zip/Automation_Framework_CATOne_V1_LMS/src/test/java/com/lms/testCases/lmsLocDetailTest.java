package com.lms.testCases;

import java.awt.AWTException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.lms.pages.locationDetailsPage;
import com.lms.pages.locationMasterPage;

public class lmsLocDetailTest extends baseClass {
	static locationDetailsPage objLD;
	
	
	@DataProvider(name = "LocationDetails")
	public static Object[][] readLocationDetailsData() throws Exception 
	{
		objLD =new locationDetailsPage();
		locationMasterPage	objLM =new locationMasterPage();
		objLM.clickLocMasterTab();
		objLD.clickLocDetailTab();	
		
		if (extentRptflag) {
			logger = report.createTest("Update Location details in the account.");
		}
		
		return objExcl.readExcelSheet("Location Details");
	}
	
	@Test(priority = 17,  dataProvider = "LocationDetails")
	public void addLocationDetailsLMS(String LocationID, String CampusName,String BuildingID, String BuildingName,
			String BuildingType, String	YearBuilt, String OccupancyCode, String	ConstructionCode,	String NumberOfStories,
			String NumberOfBuilding, String	FloorArea, String	YearUpgraded, String SprinklerType, String	RoofCover
			) throws InterruptedException, AWTException {	
		
		
		objLD.updateLocDetails( LocationID, CampusName, BuildingID, BuildingName, BuildingType, YearBuilt, OccupancyCode, 
		ConstructionCode, NumberOfStories, NumberOfBuilding, 	FloorArea, 	YearUpgraded,  SprinklerType, 	RoofCover);
	}

}
