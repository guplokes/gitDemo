package com.lms.testCases;

import java.awt.AWTException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.lms.pages.locationMasterPage;

public class lmsLocMasterTest extends baseClass {
	
	locationMasterPage objLM;
	
	@DataProvider(name = "LocationMasterData")
	public static Object[][] readLocationGroupData() throws Exception 
	{
		if (extentRptflag) {
			logger = report.createTest("Add Location Data in the Account.");
		}
		
		return objExcl.readExcelSheet("Location Master");
	}
	
	@Test(priority = 15, dataProvider = "LocationMasterData")
	public void addLocationDataonLMS(String LocName, String InceptionDate, String ExpiryDate, String StreetAddress, String	PostalName,
			String PostalCode,	String Muncipality, String	MuncipalityCode, String	City, String CityCode, String District,
			String DistrictCode, String County, String	CountyCode, String	State,	String StateCode, String Area,	String AreaCode,
			String CountryCode, String	Latitude,	String Longitude, String Cresta, String	SubCresta, String GeocodeLevel,	
			String Geocoder,	String GeocodeConfidence, String GeogScheme1, String GeogName1, String 	CurrencyCode,
			String UserDef1, String UserDef2, String UserDef3, String UserDef4, String UserDef5, String UserDef6) throws InterruptedException, AWTException {
		objLM =new locationMasterPage();
		objLM.clickLocMasterTab();
		
		objLM.addLocationData(LocName, InceptionDate, ExpiryDate, StreetAddress, PostalName, PostalCode, Muncipality, MuncipalityCode, 
		City, CityCode, District, DistrictCode, County,	CountyCode,	State, StateCode, Area, AreaCode, CountryCode, Latitude, Longitude, 
		Cresta,	SubCresta, GeocodeLevel, Geocoder, GeocodeConfidence, GeogScheme1, GeogName1, CurrencyCode, UserDef1, UserDef2, 
		UserDef3, UserDef4, UserDef5, UserDef6);
	}
	
	
	@Test(priority = 16)
	public void deleteLocationData() throws InterruptedException, AWTException
	{
		if (extentRptflag) {
			logger = report.createTest("Delete Location Data in the account.");
		}	
		
		objLM.deleteLocationData();
	}
}
