package com.lms.testCases;

import org.testng.annotations.Test;
import com.lms.pages.homePage;
import com.lms.pages.loginPage;

public class loginTest extends baseClass {
	loginPage objLogin;
	homePage objHome;
	
	@Test(priority = 1, description="Login with valid username and password.")
	public void LoginToLMS() throws InterruptedException {
		if (extentRptflag) {
			logger=report.createTest("Login to LMS", "Desc: Login with valid username and Password");
		}

		objLogin = new loginPage();
		objLogin.verifyLoginPage();
		objLogin.LoginToApp(objExcl.getStringData("login", 1, 0), objExcl.getStringData("login", 1, 1));

		objHome = new homePage();
		objHome.verifyHomePage();
	}
}
