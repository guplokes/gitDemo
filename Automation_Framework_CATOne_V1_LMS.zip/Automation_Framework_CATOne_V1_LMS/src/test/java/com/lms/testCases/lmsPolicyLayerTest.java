package com.lms.testCases;

import java.awt.AWTException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.lms.pages.policyLayerPage;

public class lmsPolicyLayerTest extends baseClass {
	policyLayerPage objPL;
	
	@DataProvider(name = "PolicyLayerData")
	public Object[][] readPLData() throws Exception 
	{
		if (extentRptflag) {
			logger = report.createTest("Add Policy Layer Data into an account");
		}
		objPL= new policyLayerPage();
		
		//Go to Policy Layer Tab
		objPL.clickPolicyLayerTab();
		return objExcl.readExcelSheet("Policy Layar Data");
	}
	
	
	@Test(priority = 6, dataProvider = "PolicyLayerData")
	public void AddPolicyLayerData(String layerName, String participation, String layerLimit, String layerAttachment) {
		objPL.addNewLayer(layerName, participation, layerLimit, layerAttachment);
	}
	
	@DataProvider(name = "ModifyPolicyLayerData")
	public Object[][] readPLModificationData() throws Exception 
	{
		return objExcl.readExcelSheet("Modify Policy Layer Data");
	}
	
	@Test(priority = 7, dataProvider = "ModifyPolicyLayerData")
	public void ModifyPolicyLayerData(String layerToModify,String layerName, String participation, String layerLimit, String layerAttachment) throws InterruptedException, AWTException {
		if (extentRptflag) {
			logger = report.createTest("Modify Any Policy Layer Data");
		}
		
		objPL.modifyALayer(layerToModify,layerName, participation, layerLimit, layerAttachment);
	}
	
	@Test(priority = 8)
	public void ClonePolicyLayerData() throws InterruptedException, AWTException {
		if (extentRptflag) {
			logger = report.createTest("Clone a Policy Layer Data");
		}
		objPL.cloneALayer(objExcl.getStringData("Policy Layar Data", 1, 0));
	}
	
	@Test(priority = 9)
	public void DeletePolicyLayerData() throws InterruptedException, AWTException {
		if (extentRptflag) {
			logger = report.createTest("Delete a Policy Layer Data");
		}
		objPL.deleteALayer(objExcl.getStringData("Policy Layar Data", 3, 0));
	}
}
