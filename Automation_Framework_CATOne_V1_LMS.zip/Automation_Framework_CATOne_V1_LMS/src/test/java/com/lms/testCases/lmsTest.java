package com.lms.testCases;

import java.awt.AWTException;
import java.text.ParseException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.lms.pages.homePage;
import com.lms.pages.lmsSearchPage;
import com.lms.pages.newAccountFormPage;

public class lmsTest extends baseClass {
	homePage objHome;
	lmsSearchPage objlmsSP;
	newAccountFormPage objNAFP;
	
	@Test(priority = 2)
	public void GoToLMS() {
		if (extentRptflag) {
			logger = report.createTest("Go to LMS");
		}

		objHome = new homePage();
		objHome.goToLMS();
		objlmsSP = new lmsSearchPage();
		objlmsSP.verifyLMSSearchPage();
	}


	//@Test(priority = 4, retryAnalyzer = RetryAnalyzer.class)
	
	@DataProvider(name = "BasicAcDetails")
	public Object[][] readExcel() throws Exception 
	{
		if (extentRptflag) {
			logger = report.createTest("Create An Acount on LMS");
		}

		objlmsSP.openNewAccountForm();
		
		objNAFP = new newAccountFormPage();
		objNAFP.verifyNewAccountFormPage();
		
		return objExcl.readExcelSheet("BasicAcDetails");
	}
	
	@Test(priority = 3, dataProvider = "BasicAcDetails")
	public void CreateNewAccount(String UWName, String Currency, String GrossPremium, String Tax, String Brokerage, String NetPremium, String LOB, String PayoutBasis, String Participation, 
			String ReinsuredName,String perilList, String IndustryType, String PolicyForm,String coverages, String UDF1,String UDF2,String UDF3, String UDF4, String UDF5, String UDF6, 
			String UDF7, String UDF8, String UDF9, String UDF10) throws InterruptedException, ParseException, AWTException {
		
		objNAFP.FillNewAcForm(UWName,Currency, GrossPremium, Tax, Brokerage, NetPremium, LOB, PayoutBasis, Participation, 
		ReinsuredName,perilList,IndustryType, PolicyForm,coverages, UDF1, UDF2, UDF3, UDF4, UDF5, UDF6, 
		UDF7, UDF8, UDF9, UDF10);
		
		//	objlmsSP.ValidateAccountCreated();
	}
	
	@Test(priority = 4)
	public void searchAnAccount() throws InterruptedException {
		if (extentRptflag) {
			logger = report.createTest("Search an Account");
		}
		objlmsSP.searchAnAccount();
		
		objlmsSP.openAcUpdateFrom();
	}
}
