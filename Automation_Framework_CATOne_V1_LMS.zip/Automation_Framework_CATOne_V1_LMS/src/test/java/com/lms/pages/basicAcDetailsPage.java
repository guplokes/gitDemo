package com.lms.pages;

import com.lms.testCases.baseClass;

public class basicAcDetailsPage extends baseClass {

}
