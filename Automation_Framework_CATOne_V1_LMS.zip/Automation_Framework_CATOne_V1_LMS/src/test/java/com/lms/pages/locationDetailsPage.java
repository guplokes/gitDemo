package com.lms.pages;

import java.awt.AWTException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.lms.testCases.baseClass;
import com.lms.utilities.handleKeyboardEvent;

public class locationDetailsPage extends baseClass {
	
	String pageTitle = "Xceedance | Add Account";

	public locationDetailsPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//a[normalize-space()='Location Details']")
	WebElement LocDetailsTab;
	
	@FindBy(xpath = "//a[normalize-space()='Location Master']")
	WebElement LocMasterTab;
	
	@FindBy(css = "[title='Edit Location Row']")
	private List<WebElement> EditLocButton;
	
	@FindBy(xpath = "//div[@title='Column Search']//i[@class='dx-icon dx-icon-search']")
	WebElement ColSearchButton;
	
	@FindBy(xpath = "//*[text()='LocationNumber']//following::td[149]")
	WebElement LocNumTextbox;
	
	@FindBy(xpath = "//*[text()='Actions']//following::td[149]")
	WebElement ActionsTextbox;
	
	@FindBy(xpath = "//*[text()='CampusName']//following::td[149]")
	WebElement CampusNameTextbox;
	
	@FindBy(xpath = "//*[text()='BuildingID']//following::td[149]")
	WebElement BuildingIDTextbox;
	
	@FindBy(xpath = "//*[text()='BuildingName']//following::td[149]")
	WebElement BuildingNameTextbox;
	
	@FindBy(xpath = "//*[text()='BuildingType']//following::td[149]")
	WebElement BuildingTypeTextbox;
	
	@FindBy(xpath = "//*[text()='YearBuilt']//following::td[149]")
	WebElement YearBuiltTextbox;
	
	@FindBy(xpath = "//*[text()='NumberOfStories']//following::td[149]")
	WebElement NoOfStoryTextbox;
	
	@FindBy(xpath = "//*[text()='NumberOfBuildings']//following::td[149]")
	WebElement NoOfBldTextbox;
	
	@FindBy(xpath = "//*[text()='FloorArea']//following::td[149]")
	WebElement FloorAreaTextbox;
	
	@FindBy(xpath = "//*[text()='YearUpgraded']//following::td[149]")
	WebElement YearUpgradedTextbox;
	
	@FindBy(xpath = "//*[text()='OccupancyCode']//following::td[149]")
	WebElement OccupancyCodeTextbox;
	
	@FindBy(xpath = "//*[text()='ConstructionCode']//following::td[149]")
	WebElement ConstructionCodeTextbox;
	
	@FindBy(xpath = "//*[text()='SprinklerType']//following::td[149]")
	WebElement SprinklerTypeTextbox;
	
	@FindBy(xpath = "//*[text()='RoofCover']//following::td[149]")
	WebElement RoofCoverTextbox;
	
	@FindBy(xpath = "//dx-select-box[@id='categoryId']//input[@role='combobox']")
	WebElement CatModifierTypeDD;
	
	@FindBy(xpath = "//dx-select-box[@id='catdataid']//input[@role='combobox']")
	WebElement DesModifierTypeDD;
	
	@FindBy(xpath = "//span[normalize-space()='Save']")
	WebElement SMSaveButton;
	
	@FindBy(xpath = "//td[@class='dx-command-edit dx-command-edit-with-icons']//a[@title='Save']")
	WebElement SaveButton;
	
	
	public void clickLocDetailTab() throws InterruptedException {
		LocDetailsTab.click();
		Thread.sleep(3000);
		logger.info("Location Details Tab is clicked and user is navigate to locaiton details tab.");
	}
	
	public void clickLocMasterTab() throws InterruptedException {
		LocMasterTab.click();
	}
	
	private void clickEditLocIcon() {
		EditLocButton.get(1).click();
		logger.info("Edit Location icon is clicked");
	}
	
	public void clickColSearchIcon() throws InterruptedException {
		ColSearchButton.click();
		Thread.sleep(1000);
		logger.info("Column search icon is clicked.");
	}
	
	public void searchLocationData(String LocID) throws InterruptedException, AWTException {
		clickColSearchIcon();
		Thread.sleep(1000);
		enterBasicLocData(LocNumTextbox, "Location Number", LocID);
		logger.info("Location ID : "+LocID+" is entered to search.");
		Thread.sleep(1000);
		clickColSearchIcon();
	}
	
	public void removeAppliedSearch() throws InterruptedException, AWTException {
		//clickColSearchIcon();
		Thread.sleep(1000);
		eleAct.moveToAnyElement(LocNumTextbox);
		handleKeyboardEvent.removeText();
		logger.info("Applied Search filter is removed");
		Thread.sleep(1000);
		clickColSearchIcon();
	}
	
	private void enterBasicLocData(WebElement element, String Key, String value) throws AWTException, InterruptedException {
		eleAct.moveToAnyElement(element);
		handleKeyboardEvent.removeText();
		eleAct.actionSendKeys(element, value);
		logger.info(Key+" : "+ value +" is entered successfully: Passed");
	}
	
	
	private void enterModifierData(WebElement Element, String Key, String Value) throws InterruptedException {
		eleAct.moveToAnyElement(Element);
		Element.click();
		Thread.sleep(500);
		CatModifierTypeDD.click();
		Thread.sleep(500);
		List<WebElement> modifierType = driver.findElements(By.xpath("//div[text()='" + Key + "']"));
		eleAct.clickElementByJS(modifierType.get(1));
		DesModifierTypeDD.click();
		Thread.sleep(500);
		List<WebElement> modifierTypeValue = driver.findElements(By.xpath("//div[text()='" + Value + "']"));
		eleAct.clickElementByJS(modifierTypeValue.get(0));
		Thread.sleep(500);
		SMSaveButton.click();	
		logger.info(Key + " : "+ Value +" is entered successfully: Passed");
	}
	
	private void clickSaveLocation() {
		SaveButton.click();
		logger.info("Location Data is updated successfully.");
	}
	
	
	public void updateLocDetails(String LocationID, String CampusName,String BuildingID, String BuildingName,
			String BuildingType, String	YearBuilt, String OccupancyCode, String	ConstructionCode,	String NumberOfStories,
			String NumberOfBuilding, String	FloorArea, String	YearUpgraded, String SprinklerType, String	RoofCover) throws AWTException, InterruptedException {
		searchLocationData(LocationID);
		
		
		elementAct.clickElement(EditLocButton.get(1), "Edit Location Button");
		elementAct.enterDataByJS(CampusNameTextbox, "Campus Name", CampusName);
		elementAct.enterDataByJS(BuildingIDTextbox,"Building ID", BuildingID);
		enterBasicLocData(BuildingNameTextbox,"Building Name", BuildingName);

		enterModifierData(BuildingTypeTextbox,"BuildingType", BuildingType);
		Thread.sleep(1000);
		elementAct.enterDataByJS(YearBuiltTextbox,"Year Built", YearBuilt);
		enterModifierData(OccupancyCodeTextbox,"OccupancyCode", OccupancyCode);
		Thread.sleep(1000);
		enterModifierData(ConstructionCodeTextbox,"ConstructionCode", ConstructionCode);
		Thread.sleep(1000);
		
		elementAct.enterDataByJS(NoOfStoryTextbox,"Number Of Stories", NumberOfStories);
		elementAct.enterDataByJS(NoOfBldTextbox,"Number Of Building", NumberOfBuilding);
		elementAct.enterDataByJS(FloorAreaTextbox,"Floor Area", FloorArea);
		elementAct.enterDataByJS(YearUpgradedTextbox,"Year Upgraded", YearUpgraded);
		
		enterModifierData(SprinklerTypeTextbox,"SprinklerType", SprinklerType);
		Thread.sleep(1000);
		enterModifierData(RoofCoverTextbox,"RoofCover", RoofCover); 
		Thread.sleep(1000);
		
		elementAct.clickElement(SaveButton, "Edit Location Button");
		
		Thread.sleep(1000);
		clickLocMasterTab();
		clickLocDetailTab();
	}
	
	public void updateLocDetails1(String LocationID, String CampusName,String BuildingID, String BuildingName,
			String BuildingType, String	YearBuilt, String OccupancyCode, String	ConstructionCode,	String NumberOfStories,
			String NumberOfBuilding, String	FloorArea, String	YearUpgraded, String SprinklerType, String	RoofCover) throws AWTException, InterruptedException {
		searchLocationData(LocationID);
		Thread.sleep(2000);
		clickEditLocIcon();
		Thread.sleep(1000);
		enterBasicLocData(CampusNameTextbox,"Campus Name", CampusName);
		Thread.sleep(1000);
		enterBasicLocData(BuildingIDTextbox,"Building ID", BuildingID);
		Thread.sleep(1000);
		enterBasicLocData(BuildingNameTextbox,"Building Name", BuildingName);
		Thread.sleep(1000);
		enterModifierData(BuildingTypeTextbox,"BuildingType", BuildingType);
		Thread.sleep(1000);
		enterBasicLocData(YearBuiltTextbox,"Year Built", YearBuilt);
		Thread.sleep(1000);
		enterModifierData(OccupancyCodeTextbox,"OccupancyCode", OccupancyCode);
		Thread.sleep(1000);
		enterModifierData(ConstructionCodeTextbox,"ConstructionCode", ConstructionCode);
		Thread.sleep(1000);
		enterBasicLocData(NoOfStoryTextbox,"Number Of Stories", NumberOfStories);
		Thread.sleep(1000);
		enterBasicLocData(NoOfBldTextbox,"Number Of Building", NumberOfBuilding);
		Thread.sleep(1000);
		enterBasicLocData(FloorAreaTextbox,"Floor Area", FloorArea);
		Thread.sleep(1000);
		enterBasicLocData(YearUpgradedTextbox,"Year Upgraded", YearUpgraded);
		Thread.sleep(1000);
		enterModifierData(SprinklerTypeTextbox,"SprinklerType", SprinklerType);
		Thread.sleep(1000);
		enterModifierData(RoofCoverTextbox,"RoofCover", RoofCover); 
		Thread.sleep(1000);
		clickSaveLocation();
		Thread.sleep(1000);
		clickLocMasterTab();
		clickLocDetailTab();
	}
}
