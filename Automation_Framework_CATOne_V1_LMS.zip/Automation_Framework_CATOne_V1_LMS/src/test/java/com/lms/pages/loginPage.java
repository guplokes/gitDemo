package com.lms.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.lms.testCases.baseClass;

public class loginPage extends baseClass {
	
String pageTitle="Xceedance";
	
	public loginPage(){
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="user-name") 
	WebElement userNameField;
	
	@FindBy(id="user-password") 
	WebElement PasswordField;
	
	@FindBy(xpath="//button[text()=' Login']") 
	WebElement loginButton;
	
	public void verifyLoginPage()
	{
		wait.waitForElement(userNameField);		
		elementAct.verifyWebPage(pageTitle, "Login Page");
	}
	
	public void LoginToApp(String strName,String Password)
	{
		elementAct.enterData(userNameField, "User Name", strName);
		elementAct.enterData(PasswordField, "Password",Password);
		elementAct.clickElement(loginButton, "Login Button");
	
	}
}
