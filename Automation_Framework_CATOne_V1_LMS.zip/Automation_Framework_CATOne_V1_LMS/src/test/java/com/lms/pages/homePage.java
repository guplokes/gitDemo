package com.lms.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.lms.testCases.baseClass;

public class homePage extends baseClass {

	String pageTitle = "Xceedance | Dashboard";

	public homePage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(className = "company-name-1")
	WebElement compName;

	@FindBy(css = "[href*='#/work-tray']")
	WebElement WorkTray;

	@FindBy(css = "[href*='#/lms/search-account']")
	WebElement LMSLink;

	public void verifyHomePage() {
		wait.waitForElement(compName);
		elementAct.verifyWebPage(pageTitle, "Home Page");
	}

	public void goToLMS() {
		elementAct.clickElement(LMSLink, "LMS Link");
	}
}
