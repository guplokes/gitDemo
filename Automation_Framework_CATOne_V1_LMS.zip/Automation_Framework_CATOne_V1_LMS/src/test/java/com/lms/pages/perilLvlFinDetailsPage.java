package com.lms.pages;

import java.awt.AWTException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.lms.testCases.baseClass;

public class perilLvlFinDetailsPage extends baseClass {
	
	String pageTitle = "Xceedance | Add Account";

	public perilLvlFinDetailsPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//a[normalize-space()='Peril Level Financial Details']")
	WebElement PerilLevelFinDetailsTab;
	
	@FindBy(xpath = "//i[@class='dx-icon dx-icon-add']")
	WebElement AddPerilFinancialButton;
	
	
	@FindBy(xpath="//div[@title='Select Peril']//input[@role='combobox']")
	WebElement PerilDD;
	
	@FindBy(xpath="//div[@title='Select Location Group']//input[@role='combobox']")
	WebElement LocGrpDD;
	
	@FindBy(xpath = "//div[@title='Column Search']//i[@class='dx-icon dx-icon-search']")
	WebElement ColSearchButton;
	
	@FindBy(xpath = "//div[@class='dx-texteditor-input-container dx-tag-container dx-native-click']")
	WebElement LayerDD;
	
	@FindBy(xpath = "//*[text()='Limit Code']//following::td[17]")
	WebElement LimitCodeDD;

	@FindBy(xpath = "//*[text()='Limit Type']//following::td[17]")
	WebElement LimitTypeDD;
	
	@FindBy(xpath = "//*[text()='Limit Basis']//following::td[17]")
	WebElement LimitBasisDD;

	@FindBy(xpath = "//*[text()='Sublimit']//following::td[17]")
	WebElement SublimitTextbox;
	
	@FindBy(xpath = "//*[text()='Sublimit Part']//following::td[17]")
	WebElement SublimitPartTextbox;
	
	@FindBy(xpath = "//*[text()='Sublimit Attachment']//following::td[17]")
	WebElement SublimitAttachmentTextbox;
	
	@FindBy(xpath = "//*[text()='Deductible']//following::td[17]")
	WebElement DeductibleTextbox;
	
	@FindBy(xpath = "//*[text()='Deductible Code']//following::td[17]")
	WebElement DedCodeDD;

	@FindBy(xpath = "//*[text()='Deductible Type']//following::td[17]")
	WebElement DedTypeDD;
	
	@FindBy(xpath = "//*[text()='Deductible Basis']//following::td[17]")
	WebElement DedBasisDD;
	
	@FindBy(xpath = "//*[text()='Min Deductible']//following::td[17]")
	WebElement MinDedTextbox;
	
	@FindBy(xpath = "//*[text()='Max Deductible']//following::td[17]")
	WebElement MaxDedTextbox;
	
	@FindBy(how=How.XPATH, using="//td[@class='dx-command-edit dx-command-edit-with-icons']//a[@title='Save']")
	private WebElement SaveButton;	
	
	@FindBy(xpath="//span[normalize-space()='Add Location Group']")
	private WebElement AddLocGrpButton;	
	
	@FindBy(xpath="//span[@class='switch switch-small checked']")
	private WebElement MDMLocGrpRadioButton;	
	
	@FindBy(xpath="//dx-text-box[@placeholder='Enter Location Group Name']//input[@role='textbox']")
	private WebElement EntrLocGrpTextbox;	
	
	@FindBy(xpath="//dx-select-box[@placeholder='Field Name']//input[@role='combobox']")
	private WebElement LGFieldNameDD;
	
	@FindBy(xpath="//dx-select-box[@placeholder='Operator']//input[@role='combobox']")
	private WebElement LGOperatorDD;	
	
	@FindBy(xpath="//dx-text-box[@placeholder='Value']//input[@role='textbox']")
	private WebElement LGValueTextbox;	
	
	@FindBy(xpath="//dx-select-box[@placeholder='Conditional Operator']//input[@role='combobox']")
	private WebElement LGCondOprDD;	
	
	@FindBy(xpath="//dx-button[@aria-label='Save']//div[@class='dx-button-content']")
	private WebElement LocGrpSaveButton;
	
	@FindBy(xpath="//div[@title='Filter Peril Financial']//div[@class='dx-button-content']")
	private WebElement FilterIcon;
	
	@FindBy(xpath="//span[contains(text(),'Reset')]")
	private List<WebElement> ResetFilterButton;
	
	@FindBy(xpath="//dx-select-box[@placeholder='Select Entity']//input[@role='combobox']")
	private WebElement EntityFilterDD;
	
	@FindBy(xpath="//select[@class='form-control ng-untouched ng-pristine ng-valid']")
	private WebElement OperatorFilterDD;
	
	@FindBy(xpath="//div[contains(@data-dx_placeholder,'Select Entity')]")
	private List<WebElement> EnityFilterUpdateDD;
	
	@FindBy(xpath="//span[normalize-space()='Filter']")
	private WebElement FilterButton;	
	
	@FindBy(xpath="//i[@class='dx-icon dx-icon-edit']")
	private WebElement UpdateIcon;
	
	@FindBy(xpath="//span[normalize-space()='Update']")
	private WebElement UpdateButton;
	
	@FindBy(xpath="//dx-select-box[@placeholder='Select Entity']//input[@role='combobox']")
	private WebElement EntityUpdateDD;
	
	public void clickPerilLvlFinTab() {
		elementAct.clickTab(PerilLevelFinDetailsTab, "Policy Level Financial Details Tab");
	}
	
	private void selectOperatorOnFilter(String opeartorValue) throws InterruptedException {
		OperatorFilterDD.click();
		Thread.sleep(1000);
		eleAct.actionSendKey(OperatorFilterDD, opeartorValue);
		Thread.sleep(5000); 
		logger.info("Operator is selected successfully: Passed");
	}
	
	private void selectEntityValueOnFilter(String entityValue) {
		
		List<WebElement> element= driver.findElements(By.xpath("//div[contains(@data-dx_placeholder,'Select Entity')]"));
		eleAct.clickElementByJS(element.get(1)); 
		element = driver.findElements(By.xpath("//div[text()='" + entityValue + "']"));
		eleAct.clickElementByJS(element.get(0)); 
		logger.info("Entity is selected successfully: Passed");
	}
	
	public void addLocationFinancialData(String perilName, String logGrpName, String layerName, String limitCode, String limitBasis, 
			String limitType, String sublimit, String sublimitPart, String sublimitAttachment, String deductible, String dedCode, 
			String dedType, String dedBasis, String minDed, String maxDed) throws InterruptedException, AWTException
			{
					elementAct.selectDDOptions(PerilDD, "Peril", perilName);
					elementAct.selectDDOptions(LocGrpDD, "Location Group", logGrpName);
					elementAct.clickElement(AddPerilFinancialButton, "Add New Peril Financial Button");
					elementAct.selectDDOptions(LayerDD, "Layer", layerName);
					elementAct.selectDDOptions(LimitCodeDD, "Limit Code", limitCode);
					//elementAct.selectDDOptions(LimitBasisDD, "Limit Basis", limitBasis);
					elementAct.selectDDOptions(LimitTypeDD, "Limit Type", limitType);
					elementAct.enterDataByJS(SublimitTextbox, "Sub-limit", sublimit);
					elementAct.enterDataByJS(SublimitPartTextbox, "Sub-limit Part", sublimitPart);
					elementAct.enterDataByJS(SublimitAttachmentTextbox, "Sub-limit Attachement", sublimitAttachment);
					elementAct.enterDataByJS(DeductibleTextbox, "Deductible", deductible);
					elementAct.selectDDOptions(DedCodeDD, "Ded Code", dedCode);
					elementAct.selectDDOptions(DedTypeDD, "Ded Type", dedType);
					elementAct.enterDataByJS(MinDedTextbox, "Min Deductible", minDed);
					elementAct.enterDataByJS(MaxDedTextbox, "Max Deductible", maxDed);
					elementAct.clickElement(SaveButton, "Save Button");
			}
	
	public void addLocationGroup(String locGrpName, String fieldName, String Operator, String value, String conOpr) throws InterruptedException, AWTException {
		elementAct.clickElement(AddLocGrpButton, "Add Location Group Button");
		elementAct.disableRadioButton(MDMLocGrpRadioButton, "MDM LOC Group Radio Button");
		elementAct.enterDataByJS(EntrLocGrpTextbox, "Location Group", locGrpName);
		elementAct.selectDDOptions(LGFieldNameDD, "Field Name", fieldName);
		elementAct.selectDDOptions(LGOperatorDD, "Operator", Operator);
		elementAct.enterDataByJS(LGValueTextbox, "Value", value);
		elementAct.selectDDOptions(LGCondOprDD, "Conditional Operator", conOpr);
		elementAct.moveToAnyElement(LocGrpSaveButton, "Save Location Group Button");
		elementAct.clickElement(LocGrpSaveButton, "Save Location Group Button");
	}
	
	public void applyFilter() throws InterruptedException
	{
		elementAct.clickElement(FilterIcon, "Filter Icon");
		elementAct.clickElement(ResetFilterButton.get(0), "Reset Button");
		elementAct.selectDDOptions(EntityFilterDD, "Entity", "LimitBasis");
		//elementAct.selectDDOptions(OperatorFilterDD, "Operator", "Contains");
		Thread.sleep(500);
		selectOperatorOnFilter("Contains");
		Thread.sleep(500);
		selectEntityValueOnFilter("Building");
		Thread.sleep(500);
		elementAct.clickElement(FilterButton, "Filter Button");
	}
	
	public void bulkUpdatePerilFin() throws InterruptedException
	{
		elementAct.clickElement(UpdateIcon, "Update Icon");
		elementAct.clickElement(ResetFilterButton.get(0), "Reset Button");
		elementAct.selectDDOptions(EnityFilterUpdateDD.get(0), "Entity", "LimitType");
		elementAct.selectDDOptions(EnityFilterUpdateDD.get(1), "Entity", "Amount");
		elementAct.clickElement(UpdateButton, "Update Button");
	}
}
