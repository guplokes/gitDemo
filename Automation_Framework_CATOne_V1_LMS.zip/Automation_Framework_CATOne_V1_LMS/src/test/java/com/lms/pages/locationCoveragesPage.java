package com.lms.pages;

import java.awt.AWTException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.lms.testCases.baseClass;
import com.lms.utilities.handleKeyboardEvent;

public class locationCoveragesPage extends baseClass {

	public locationCoveragesPage(WebDriver ldriver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[normalize-space()='Location Coverages']")
	WebElement tabLocCov;
	
	@FindBy(xpath = "//a[normalize-space()='Location Master']")
	WebElement tabLocMaster;
	
	@FindBy(xpath="//div[@title='Select Peril']//input[@role='combobox']")
	WebElement ddPeril;
	
	@FindBy(xpath="//i[@class='dx-icon dx-icon-add']")
	WebElement btnAddPeril;
	
	@FindBy(xpath="//i[@class='dx-icon dx-icon-trash']")
	WebElement btndeletePeril;
	
	@FindBy(xpath="//button[normalize-space()='Yes, Delete']")
	WebElement btncnfdeletePeril;
	
	@FindBy(css = "[title='Edit Location Coverage']")
	//@FindBy(xpath="//a[@title='Edit Location Coverage']")
	List<WebElement> icEditLocCov;
	
	@FindBy(xpath="//td[@class='dx-command-edit dx-command-edit-with-icons dx-cell-focus-disabled']//a[@title='Clear Location Coverage']")
	WebElement icClearLocCov;
	
	@FindBy(xpath="//div[@title='Column Search']//i[@class='dx-icon dx-icon-search']")
	WebElement icSearch;
	
	@FindBy(xpath="//td[@class='dx-command-edit dx-command-edit-with-icons']//a[@title='Save']")
	WebElement icSaveLocCov;
	
	@FindBy(xpath = "//*[@id=\"toast-container\"]")
	WebElement lblAcCreation;

	@FindBy(xpath="//*[text()='LocationNumber']//following::td[29]")
	WebElement txtLocNum;
	
	@FindBy(xpath="//*[text()='Building TIV 1']//following::td[29]")
	WebElement txtBuildTiv1;
	
	@FindBy(xpath="//*[text()='Building TIV 2']//following::td[29]")
	WebElement txtBuildTiv2;
	
	@FindBy(xpath="//*[text()='Building TIV 3']//following::td[29]")
	WebElement txtBuildTiv3;
	
	@FindBy(xpath="//*[text()='Content TIV 1']//following::td[29]")
	WebElement txtContTiv1;
	
	@FindBy(xpath="//*[text()='Content TIV 2']//following::td[29]")
	WebElement txtContTiv2;
	
	@FindBy(xpath="//*[text()='Content TIV 3']//following::td[29]")
	WebElement txtConTiv3;
	
	@FindBy(xpath="//*[text()='Damagebility 1']//following::td[29]")
	WebElement txtDamagebility1;
	
	@FindBy(xpath="//*[text()='Damagebility 2']//following::td[29]")
	WebElement txtDamagebility2;
	
	@FindBy(xpath="//*[text()='Damagebility 3']//following::td[29]")
	WebElement txtDamagebility3;
	
	@FindBy(xpath="//*[text()='Other TIV 1']//following::td[29]")
	WebElement txtOtherTiv1;
	
	@FindBy(xpath="//*[text()='Other TIV 2']//following::td[29]")
	WebElement txtOtherTiv2;
	
	@FindBy(xpath="//*[text()='Other TIV 3']//following::td[29]")
	WebElement txtOtherTiv3;
	
	@FindBy(xpath="//*[text()='BI TIV 1']//following::td[29]")
	WebElement txtBITiv1;
	
	@FindBy(xpath="//*[text()='BI TIV 2']//following::td[29]")
	WebElement txtBITiv2;
	
	@FindBy(xpath="//*[text()='BI TIV 3']//following::td[29]")
	WebElement txtBITiv3;
	
	@FindBy(xpath="//*[text()='BI POI 1']//following::td[29]")
	WebElement txtBIPoi1;
	
	@FindBy(xpath="//*[text()='BI POI 2']//following::td[29]")
	WebElement txtBIPoi2;
	
	@FindBy(xpath="//*[text()='BI POI 3']//following::td[29]")
	WebElement txtBIPoi3;
	
	@FindBy(xpath="//*[text()='Waiting Period']//following::td[29]")
	WebElement txtWaitingPeriod;
	
	@FindBy(xpath="//div[@aria-label='Warning']")
	List<WebElement> msgWarnig;
	
	
	
	public void clickLocCovTab() throws InterruptedException {
		tabLocCov.click();
		Thread.sleep(3000);
		logger.info("Location Coverage Tab is clicked and user is navigate to locaiton coverage tab.");
	}
	
	public void clickLocMasterTab() throws InterruptedException {
		tabLocMaster.click();
	}
	
	private void selectPeril(String PerilName) {
		eleAct.clickElementByJS(ddPeril);
		driver.findElement(By.xpath("//div[contains(text(),'"+PerilName+"')]")).click();
		//List<WebElement> element = driver.findElements(By.xpath("//div[text()='" + PerilName + "']"));
		//eleAct.clickElement(element.get(0));
		logger.info("Peril is selected successfully");
	}
	
	private void clickAddPeril(String perilName) throws InterruptedException {
		btnAddPeril.click();
		Thread.sleep(1000);
		if(msgWarnig.size()>0)
		{
			logger.info("Peril data is alreay exist it returning the message: "+msgWarnig.get(0).getText());
		}
		Thread.sleep(5000);
		logger.info("Coverage datails is added for peril: "+perilName);
	}
	
	private void clickdeletePeril(String perilName) throws InterruptedException {
		btndeletePeril.click();
		Thread.sleep(5000);
		btncnfdeletePeril.click();
		Thread.sleep(5000);
		logger.info("Coverage datails for peril "+perilName+" is deleted successfully.");
	}
	
	
	private void enterLocCovData(WebElement element, String Key, String value) throws AWTException, InterruptedException {
		eleAct.moveToAnyElement(element);
		handleKeyboardEvent.removeText();
		eleAct.actionSendKeys(element, value);
		logger.info(Key+" : "+ value +" is entered successfully: Passed");
	}
	
	private void clickEditLocIcon() {
		icEditLocCov.get(1).click();
		logger.info("Edit Location Coverage icon is clicked");
	}
	
	public void clickColSearchIcon() throws InterruptedException {
		icSearch.click();
		Thread.sleep(1000);
		logger.info("Column Search icon is clicked.");
	}
	
	public void searchLocationData(String LocID) throws InterruptedException, AWTException {
		clickColSearchIcon();
		Thread.sleep(1000);
		enterLocCovData(txtLocNum, "Location Number", LocID);
		logger.info("Location ID : "+LocID+" is entered to search.");
		Thread.sleep(1000);
		clickColSearchIcon();
	}
	
	public void addCovDatailofPeril() throws InterruptedException
	{
		selectPeril("Fire Following");
		Thread.sleep(5000);
		clickAddPeril("Fire Following");
		Thread.sleep(5000);
	}
	
	public void deleteCovDatailofPeril() throws InterruptedException
	{
		selectPeril("Fire Following");
		Thread.sleep(5000);
		clickdeletePeril("Fire Following");
		Thread.sleep(5000);
		
	}
	
	public void updateLocCoverages(String locID, String BuildTIV1,String BuildTIV2,String BuildTIV3,String ContTIV1,
			String ContTIV2,String ContTIV3,String Damagebility1, String Damagebility2, String	Damagebility3, String	OtherTIV1,
			String OtherTIV2, String OtherTIV3,	String BITIV1, String BITIV2, String BITIV3, String	BIPOI1, String	BIPOI2,
			String BIPOI3, String WaitingPeriod) throws AWTException, InterruptedException {
		Thread.sleep(2000);
		searchLocationData(locID);
		Thread.sleep(5000);
		clickEditLocIcon();
		Thread.sleep(5000);
		enterLocCovData(txtBuildTiv1,"Building TIV 1", BuildTIV1);
		Thread.sleep(1000);
		enterLocCovData(txtBuildTiv2,"Building TIV 2", BuildTIV2);
		Thread.sleep(1000);
		enterLocCovData(txtBuildTiv3,"Building TIV 3", BuildTIV3);
		Thread.sleep(1000);
		enterLocCovData(txtContTiv1,"Content TIV 1", ContTIV1);
		Thread.sleep(1000);
		enterLocCovData(txtContTiv2,"Content TIV 2", ContTIV2);
		Thread.sleep(1000);
		enterLocCovData(txtConTiv3,"Content TIV 3", ContTIV3);
		Thread.sleep(1000);
		enterLocCovData(txtDamagebility1,"Damagebility 1", Damagebility1);
		Thread.sleep(1000);
		enterLocCovData(txtDamagebility2,"Damagebility 2", Damagebility2);
		Thread.sleep(1000);
		enterLocCovData(txtDamagebility3,"Damagebility 3", Damagebility3);
		Thread.sleep(1000);
		enterLocCovData(txtOtherTiv1,"Other TIV 1", OtherTIV1);
		Thread.sleep(1000);
		enterLocCovData(txtOtherTiv2,"Other TIV 2", OtherTIV2);
		Thread.sleep(1000);
		enterLocCovData(txtOtherTiv3,"Other TIV 3", OtherTIV3);
		Thread.sleep(1000);
		enterLocCovData(txtBITiv1,"BI TIV 1", BITIV1);
		Thread.sleep(1000);
		enterLocCovData(txtBITiv2,"BI TIV 2", BITIV2);
		Thread.sleep(1000);
		enterLocCovData(txtBITiv3,"BI TIV 3", BITIV3);
		Thread.sleep(1000);
		enterLocCovData(txtBIPoi1,"BI POI 1", BIPOI1);
		Thread.sleep(1000);
		enterLocCovData(txtBIPoi2,"BI POI 2", BIPOI2);
		Thread.sleep(1000);
		enterLocCovData(txtBIPoi3,"BI POI 3", BIPOI3);
		Thread.sleep(1000);
		enterLocCovData(txtWaitingPeriod,"Waiting Period", WaitingPeriod);
		Thread.sleep(1000);
		icSaveLocCov.click();
		Thread.sleep(1000);
		clickLocMasterTab();
		clickLocCovTab();
	}
}
