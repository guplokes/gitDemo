package com.lms.pages;

import java.awt.AWTException;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.lms.testCases.baseClass;
import com.lms.utilities.handleKeyboardEvent;

public class locationMasterPage extends baseClass{
	
	String pageTitle = "Xceedance | Add Account";

	public locationMasterPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//h5[normalize-space()='Location']")
	WebElement LocationTab;
	
	@FindBy(xpath = "//i[@class='dx-icon dx-icon-add']")
	WebElement AddLocationButton;
	
	@FindBy(xpath = "//div[@title='Column Search']//div[@class='dx-button-content']")
	WebElement ColSearchButton;
	
	@FindBy(xpath = "//div[@title='Expand Screen']//i[@class='dx-icon dx-icon-expand']")
	WebElement ExpandScreenButton;
	
	@FindBy(xpath = "//*[text()='LocationName']//following::td[46]")
	WebElement LocNameTextbox;
	
	@FindBy(xpath = "//*[text()='InceptionDate']//following::td[46]")
	WebElement InceptionDateCAL;
	
	@FindBy(xpath = "//*[text()='ExpiryDate']//following::td[46]")
	WebElement ExpiryDateCAL;
	
	@FindBy(xpath = "//*[text()='StreetAddress']//following::td[46]")
	WebElement StreetAddressTextbox;
	
	@FindBy(xpath = "//*[text()='PostalName']//following::td[46]")
	WebElement PostalNameTextbox;
	
	@FindBy(xpath = "//*[text()='PostalCode']//following::td[46]")
	WebElement PostalCodeTextbox;
	
	@FindBy(xpath = "//*[text()='Muncipality']//following::td[46]")
	WebElement MuncipalityTextbox;
	
	@FindBy(xpath = "//*[text()='MuncipalityCode']//following::td[46]")
	WebElement MuncipalityCodeTextbox;
	
	@FindBy(xpath = "//*[text()='City']//following::td[46]")
	WebElement CityTextbox;
	
	@FindBy(xpath = "//*[text()='CityCode']//following::td[46]")
	WebElement CityCodeTextbox;
	
	@FindBy(xpath = "//*[text()='District']//following::td[46]")
	WebElement DistrictTextbox;
	
	@FindBy(xpath = "//*[text()='DistrictCode']//following::td[46]")
	WebElement DistrictCodeTextbox;
	
	@FindBy(xpath = "//*[text()='County']//following::td[46]")
	WebElement CountyTextbox;
	
	@FindBy(xpath = "//*[text()='CountyCode']//following::td[46]")
	WebElement CountyCodeTextbox;
	
	@FindBy(xpath = "//*[text()='State']//following::td[46]")
	WebElement StateTextbox;
	
	@FindBy(xpath = "//*[text()='StateCode']//following::td[46]")
	WebElement StateCodeTextbox;
	
	@FindBy(xpath = "//*[text()='Area']//following::td[46]")
	WebElement AreaTextbox;
	
	@FindBy(xpath = "//*[text()='AreaCode']//following::td[46]")
	WebElement AreaCodeTextbox;
	
	@FindBy(xpath = "//*[text()='CountryCode']//following::td[46]")
	WebElement CountryCodeTextbox;
	
	@FindBy(xpath = "//*[text()='Latitude']//following::td[46]")
	WebElement LatitudeTextbox;
	
	@FindBy(xpath = "//*[text()='Longitude']//following::td[46]")
	WebElement LongitudeTextbox;
	
	@FindBy(xpath = "//*[text()='Cresta']//following::td[46]")
	WebElement CrestaTextbox;
	
	@FindBy(xpath = "//*[text()='SubCresta']//following::td[46]")
	WebElement SubCrestaTextbox;
	
	@FindBy(xpath = "//*[text()='Geocode_Level']//following::td[46]")
	WebElement GeocodeLvlTextbox;
	
	@FindBy(xpath = "//*[text()='Geocoder']//following::td[46]")
	WebElement GeocoderTextbox;
	
	@FindBy(xpath = "//*[text()='GeocodeConfidence']//following::td[46]")
	WebElement GeocodeConfTextbox;
	
	@FindBy(xpath = "//*[text()='GeogScheme1']//following::td[46]")
	WebElement GeogSch1Textbox;
	
	@FindBy(xpath = "//*[text()='GeogName1']//following::td[46]")
	WebElement GeogName1Textbox;
	
	@FindBy(xpath = "//*[text()='CurrencyCode']//following::td[46]")
	WebElement CurrencyCodeTextbox;
	
	@FindBy(xpath = "//*[text()='LocUserDef1']//following::td[46]")
	WebElement LocUDF1Textbox;
	
	@FindBy(xpath = "//*[text()='LocUserDef2']//following::td[46]")
	WebElement LocUDF2Textbox;
	
	@FindBy(xpath = "//*[text()='LocUserDef3']//following::td[46]")
	WebElement LocUDF3Textbox;
	
	@FindBy(xpath = "//*[text()='LocUserDef4']//following::td[46]")
	WebElement LocUDF4Textbox;
	
	@FindBy(xpath = "//*[text()='LocUserDef5']//following::td[46]")
	WebElement LocUDF5Textbox;
	
	@FindBy(xpath = "//*[text()='LocUserDef6']//following::td[46]")
	WebElement LocUDF6Textbox;
	
	
	@FindBy(xpath = "//td[@class='dx-command-edit dx-command-edit-with-icons']//a[@title='Save']")
	WebElement SaveIcon;
	
	@FindBy(css = "[title='Delete']")
	List<WebElement> DeleteButton;
	
	@FindBy(xpath = "//span[normalize-space()='Yes']")
	WebElement CNFYesToDelete;
	
	@FindBy(xpath = "//*[text()='LocationNumber']//following::td[46]")
	WebElement LocNumberTextbox;
	
	public void clickLocMasterTab() throws InterruptedException {
		elementAct.clickElement(LocationTab, "Location Tab");
	}
	
	private void selectInceptionDate(String inceptionDateValue) throws AWTException, InterruptedException {
		eleAct.moveToAnyElement(InceptionDateCAL);
		eleAct.actionSendKeys(InceptionDateCAL, inceptionDateValue);
		logger.info("Inception Date :  , "+ inceptionDateValue +" is selected successfully: Passed");
	}
	
	private void selectExpiryDate(String expiryDateValue) throws AWTException, InterruptedException {
		eleAct.moveToAnyElement(ExpiryDateCAL);
		eleAct.actionSendKeys(ExpiryDateCAL, expiryDateValue);
		logger.info("Expiry Date :  , "+ expiryDateValue +" is selected successfully: Passed");
	}
	
	public void deleteLocationData() throws InterruptedException, AWTException
	{
		String LocationtoDelete="3";
		elementAct.clickElement(ColSearchButton, "Col Search Button");
		elementAct.enterDataByJS(LocNumberTextbox, "Location Number", LocationtoDelete);
		elementAct.clickElement(DeleteButton.get(1), "Delete Location Button");
		elementAct.clickElement(CNFYesToDelete, "CNF Yes To Delete");
		elementAct.moveToAnyElement(LocNumberTextbox, "Location Number");
		handleKeyboardEvent.removeText();
		elementAct.clickElement(ColSearchButton, "Col Search Button");
		logger.pass("Location '"+LocationtoDelete+"' is deleted successfully.");
	}
	
	public void addLocationData(String LocName, String InceptionDate, String ExpiryDate, String StreetAddress, String	PostalName,
			String PostalCode,	String Muncipality, String	MuncipalityCode, String	City, String CityCode, String District,
			String DistrictCode, String County, String	CountyCode, String	State,	String StateCode, String Area,	String AreaCode,
			String CountryCode, String	Latitude, String Longitude, String Cresta, String	SubCresta, String GeocodeLevel,	
			String Geocoder, String GeocodeConfidence, String GeogScheme1, String GeogName1, String CurrencyCode,
			String UserDef1, String UserDef2, String UserDef3, String UserDef4, String UserDef5, String UserDef6) throws AWTException, InterruptedException  {
		elementAct.clickElement(AddLocationButton, "Add Location Button");
		elementAct.enterDataByJS(LocNameTextbox, "Location Name", LocName);
		selectInceptionDate(InceptionDate);
		selectExpiryDate(ExpiryDate);
		elementAct.enterDataByJS(StreetAddressTextbox, "Street Address", StreetAddress);
		elementAct.enterDataByJS(PostalNameTextbox, "Postal Name", PostalName);
		elementAct.enterDataByJS(PostalCodeTextbox, "Postal Code", PostalCode);
		elementAct.enterDataByJS(MuncipalityTextbox, "Muncipality", Muncipality);
		elementAct.enterDataByJS(MuncipalityCodeTextbox, "Muncipality Code", MuncipalityCode);
		elementAct.enterDataByJS(CityTextbox, "City", City);
		elementAct.enterDataByJS(CityCodeTextbox, "City Code", CityCode);
		elementAct.enterDataByJS(DistrictTextbox, "District", District);
		elementAct.enterDataByJS(DistrictCodeTextbox, "District Code", DistrictCode);
		elementAct.enterDataByJS(CountyTextbox, "County", County);
		elementAct.enterDataByJS(CountyCodeTextbox, "County Code", CountyCode);
		elementAct.enterDataByJS(StateTextbox, "State", State);
		elementAct.enterDataByJS(StateCodeTextbox, "State Code", StateCode);
		elementAct.enterDataByJS(AreaTextbox, "Area", Area);
		elementAct.enterDataByJS(AreaCodeTextbox, "Area Code", AreaCode);
		elementAct.enterDataByJS(CountryCodeTextbox, "Country Code", CountryCode);
		elementAct.enterDataByJS(LatitudeTextbox, "Latitude", Latitude);
		elementAct.enterDataByJS(LongitudeTextbox, "Longitude", Longitude);
		elementAct.enterDataByJS(CrestaTextbox, "Cresta", Cresta);
		elementAct.enterDataByJS(SubCrestaTextbox, "Sub Cresta", SubCresta);
		elementAct.enterDataByJS(GeocodeLvlTextbox, "Geocode Level", GeocodeLevel);
		elementAct.enterDataByJS(GeocoderTextbox, "Geocoder", Geocoder);
		elementAct.enterDataByJS(GeocodeConfTextbox, "Geocode Confidence", GeocodeConfidence);
		elementAct.enterDataByJS(GeogSch1Textbox, "Geog Scheme 1", GeogScheme1);
		elementAct.enterDataByJS(GeogName1Textbox, "Geog Name 1", GeogName1);
		elementAct.enterDataByJS(CurrencyCodeTextbox, "Currency Code", CurrencyCode);
		elementAct.enterDataByJS(LocUDF1Textbox, "UserDef1", UserDef1);
		elementAct.enterDataByJS(LocUDF2Textbox, "UserDef2", UserDef2);
		elementAct.enterDataByJS(LocUDF3Textbox, "UserDef3", UserDef3);
		elementAct.enterDataByJS(LocUDF4Textbox, "UserDef4", UserDef4);
		elementAct.enterDataByJS(LocUDF5Textbox, "UserDef5", UserDef5);
		elementAct.enterDataByJS(LocUDF6Textbox, "UserDef6", UserDef6);
		elementAct.clickElement(SaveIcon, "Save Button");
	}
}
