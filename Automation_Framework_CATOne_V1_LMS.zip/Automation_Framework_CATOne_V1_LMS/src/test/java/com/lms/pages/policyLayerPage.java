package com.lms.pages;

import java.awt.AWTException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.lms.testCases.baseClass;
import com.lms.utilities.handleKeyboardEvent;

public class policyLayerPage extends baseClass {

	String pageTitle = "Xceedance | Add Account";

	public policyLayerPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//*[text()=' Policy Layer']")
	WebElement PolicyLayerTab;
	
	@FindBy(css = "[title='Add New Layer']")
	WebElement AddNewLayerButton;
	
	@FindBy(css = "[title='Column Search']")
	WebElement ColSearchButton;
	
	@FindBy(xpath = "//*[text()='Layer Name']//following::td[5]")
	WebElement LayerNameTextbox;

	@FindBy(xpath = "//*[text()='Layer Name']//following::td[6]")
	//@FindBy(xpath = "//*[text()='Participation']//following::td[5]")
	WebElement ParticipationTextbox;
	
	@FindBy(xpath = "//*[text()='Layer Limit']//following::td[5]")
	WebElement LayerLimitTextbox;
	
	@FindBy(xpath = "//*[text()='Layer Attachment']//following::td[5]")
	WebElement LayerAttachmentTextbox;
	
	@FindBy(xpath="//a[@title='Save']")
	private WebElement SaveButton;
	
	@FindBy(css = "[title='Clone']")
	WebElement CloneButton;
	
	@FindBy(css = "[title='Cancel']")
	WebElement CancelButton;
	
	@FindBy(css = "[title='Edit']")
	WebElement EditButton;
	
	@FindBy(css = "[title='Delete']")
	WebElement DeleteButton;
	
	@FindBy(xpath = "//*[text()='Yes']")
	WebElement DeleteButtonCNF;
	
	public void clickPolicyLayerTab() {
		elementAct.clickTab(PolicyLayerTab, "Policy Layer Tab");
	}
	
	public void addNewLayer(String layerName, String Participation, String layerLimit, String layerAttachment) {
		elementAct.clickElement(AddNewLayerButton, "Add New Layer Button");
		elementAct.enterDataByJS(LayerNameTextbox, "Layer Name", layerName);
		elementAct.enterDataByJS(ParticipationTextbox, "Participation", Participation);
		elementAct.enterDataByJS(LayerLimitTextbox, "Layer Limit", layerLimit);
		elementAct.enterDataByJS(LayerAttachmentTextbox, "Layer Attachment",layerAttachment);
		elementAct.clickElement(SaveButton, "Save Button");
	}
	
	public void cloneALayer(String LayerName) throws AWTException, InterruptedException {
		elementAct.clickElement(ColSearchButton, "Column Search Button");
		elementAct.enterDataByJS(LayerNameTextbox, "Layer Name", LayerName);
		elementAct.clickElement(CloneButton, "Clone Layer Button");
		elementAct.moveToAnyElement(LayerNameTextbox,"Layer Name");
		handleKeyboardEvent.removeText();
		elementAct.clickElement(ColSearchButton, "Column Search Button");
		logger.pass("Clone of a Layer: "+LayerName+" is created successfully.");
	}
	
	public void deleteALayer(String LayerName) throws AWTException, InterruptedException {
		elementAct.clickElement(ColSearchButton, "Column Search Button");
		elementAct.enterDataByJS(LayerNameTextbox, "Layer Name", LayerName);
		elementAct.clickElement(DeleteButton, "Delete Layer Button");
		elementAct.clickElement(DeleteButtonCNF, "Yes Delete Confirmation");
		elementAct.moveToAnyElement(LayerNameTextbox,"Layer Name");
		handleKeyboardEvent.removeText();
		elementAct.clickElement(ColSearchButton, "Column Search Button");
		logger.pass("Layer: "+LayerName+" is deleted successfully.");
	}
	
	public void modifyALayer(String layerToModify, String LayerName, String Participation, String LayerLimit, String LayerAttachement) throws AWTException, InterruptedException {
		elementAct.clickElement(ColSearchButton, "Column Search Button");
		elementAct.enterDataByJS(LayerNameTextbox, "Layer Name", layerToModify);
		elementAct.clickElement(EditButton, "Edit Layer Button");
		elementAct.clickElement(ColSearchButton, "Column Search Button");
		elementAct.enterDataByJS(LayerNameTextbox, "Layer Name", LayerName);
		elementAct.enterDataByJS(ParticipationTextbox, "Participation", Participation);
		elementAct.enterDataByJS(LayerLimitTextbox, "Layer Limit", LayerLimit);
		elementAct.enterDataByJS(LayerAttachmentTextbox, "Layer Attachment",LayerAttachement);
		elementAct.clickElement(SaveButton, "Save Button");
		elementAct.clickElement(ColSearchButton, "Column Search Button");
		elementAct.moveToAnyElement(LayerNameTextbox, "Layer Name");
		handleKeyboardEvent.removeText();
		elementAct.clickElement(ColSearchButton, "Column Search Button");
		logger.pass("Layer details for '"+layerToModify+"' are modified successfully.");
	}
}
