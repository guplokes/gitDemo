package com.lms.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.lms.testCases.baseClass;

public class lmsSearchPage extends baseClass {

	public lmsSearchPage() {
		PageFactory.initElements(driver, this);
	}

	String pageTitle = "Xceedance | Search Account";

	@FindBy(xpath = "//*[text()='Accounts']")
	WebElement LMSPageVerifiation;

	@FindBy(xpath = "//*[@id=\"toast-container\"]")
	WebElement AcCreationLabel;

	@FindBy(css = "[title='New Account']")
	WebElement AddNewAcButton;

	@FindBy(css = "[title='Column Search']")
	WebElement columnSearchButton;

	@FindBy(css = "[title=' Update Account']")
	WebElement UpdateAcButton;
	
	@FindBy(xpath = "//input[@aria-autocomplete='inline']")
	WebElement SearchAcByNameTextBox;
	
	@FindBy(xpath = "//dx-button[@aria-label='search']//i[@class='dx-icon dx-icon-search']")
	WebElement SearchAcByNameIcon;
	
	String AcCreationMsg = "Data Saved Successfully.";
	
	public void verifyLMSSearchPage()
	{
		wait.waitForElement(LMSPageVerifiation);		
		elementAct.verifyWebPage(pageTitle, "LMS Search Page");
	}
	
	public void openNewAccountForm() {
		wait.waitForElement(AddNewAcButton);
		elementAct.clickElement(AddNewAcButton, "New Account Button");
	}
	
	public void searchAnAccount()  {
		LMSAcName="Next Level Church - SOV_2";
		wait.waitForElement(SearchAcByNameTextBox);
		elementAct.enterData(SearchAcByNameTextBox, "Account Name Search", LMSAcName);
		wait.waitForElement(SearchAcByNameIcon);
		elementAct.clickElement(SearchAcByNameIcon, "Search Icon");
		elementAct.searchElement(LMSAcName, "Account");	
	}
	
	public void openAcUpdateFrom() {
		wait.waitForElement(UpdateAcButton);
		elementAct.clickElement(UpdateAcButton, "Update Account Button");
	}

	public void verifyAccountCreation() throws InterruptedException {
		wait.waitForElement(AcCreationLabel);
		elementAct.verifyMessage(AcCreationLabel, AcCreationMsg, "Account Creation");
	}	
}
