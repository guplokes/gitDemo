package com.lms.pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.lms.testCases.baseClass;

public class policyBlanketDetailsPage extends baseClass {
	
	String pageTitle = "Xceedance | Add Account";

	public policyBlanketDetailsPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[text()=' Policy Blanket Details']")
	WebElement PolicyBlanketTab;
	
	@FindBy(css = "[title='Add Blanket']")
	WebElement AddNewBlanketButton;
	
	@FindBy(xpath="//div[contains(@data-dx_placeholder,'Select Peril')]")
	WebElement PerilDD;
	
	@FindBy(css = "[title='Column Search']")
	WebElement ColSearchButton;
	
	@FindBy(xpath = "//*[text()='Deductible Code']//following::td[13]")
	WebElement DedCodeDD;

	@FindBy(xpath = "//*[text()='Deductible Type']//following::td[13]")
	WebElement DedTypeDD;
	
	@FindBy(xpath = "//*[text()='Deductible Basis']//following::td[13]")
	WebElement DedBasisDD;
	
	@FindBy(xpath = "//*[text()='Blanket Deductible']//following::td[13]")
	WebElement BlanketDedTextbox;
	
	@FindBy(xpath = "//*[text()='Maximum Deductible']//following::td[13]")
	WebElement MaxDedTextbox;
	
	@FindBy(xpath = "//*[text()='Minimum Deductible']//following::td[13]")
	WebElement MinDedTextbox;
	
	@FindBy(xpath = "//*[text()='Limit Code']//following::td[13]")
	WebElement LimitCodeDD;
	
	@FindBy(xpath = "//*[text()='Limit Type']//following::td[13]")
	WebElement LimitTypeDD;
	
	@FindBy(xpath = "//*[text()='Limit Basis']//following::td[13]")
	WebElement LimitBasisDD;
	
	@FindBy(xpath = "//*[text()='Limit Amount']//following::td[13]")
	WebElement LimitAmtTextbox;
	
	@FindBy(xpath = "//*[text()='Peril Name']//following::td[13]")
	WebElement PerilNameSearchDD;
	
	@FindBy(xpath="//td[@class='dx-command-edit dx-command-edit-with-icons']//a[@title='Save']")
	private WebElement SaveButton;
	
	@FindBy(css = "[title='Clone']")
	WebElement CancelButton;
	
	@FindBy(css = "[title='Edit']")
	WebElement EditButton;
	
	@FindBy(css = "[title='Delete']")
	WebElement DeleteButton;
	
	//@FindBy(xpath = "//*[text()='Yes']")
	//WebElement btnDeleteCnf;

	public void clickPolicyBlanketTab() {
		elementAct.clickTab(PolicyBlanketTab, "Policy Blanket Tab");
	}
	
	private void clickDeleteIcon()
	{
		List<WebElement> element = driver.findElements(By.cssSelector("[title='Delete']"));
		element.get(2).click();
	}
	
	public void addBlanketData(String Peril,String dedCode, String dedType, String dedBasis, String blanketDed, 
			String maxDed, String minDed, String limitCode, String limitType, String limitBasis, String limitAmt) {
		elementAct.selectDDOptions(PerilDD, "Peril", Peril);
		elementAct.clickElement(AddNewBlanketButton, "Add New Blanket Button");
		elementAct.selectDDOptions(DedCodeDD, "Deductible Code", dedCode);
		elementAct.selectDDOptions(DedTypeDD, "Deductible Type", dedType);
		elementAct.selectDDOptions(DedBasisDD, "Deductible Basis", dedBasis);
		elementAct.enterDataByJS(BlanketDedTextbox, "Blanket Deductible", blanketDed);
		elementAct.enterDataByJS(MaxDedTextbox, "Max Deductible", maxDed);
		elementAct.enterDataByJS(MinDedTextbox, "Min Deductible", minDed);
		elementAct.selectDDOptions(LimitCodeDD, "Limit Code", limitCode);
		elementAct.selectDDOptions(LimitTypeDD, "Limit Type", limitType);
		elementAct.enterDataByJS(LimitAmtTextbox, "Limit Amount", limitAmt);
		elementAct.clickElement(SaveButton, "Save Button");
		logger.pass("A new policy blanket details for Peril: '"+Peril+"' are added successfully.");
	}
	
	public void deleteBlanketDetails() throws InterruptedException
	{
		//clickSearch();
		//Thread.sleep(500);
		//ddPerilNameSearch.click();
		//Thread.sleep(500);
		//selectPerilforSeach("All Flood");
		Thread.sleep(500);
		clickDeleteIcon();
	}

}
