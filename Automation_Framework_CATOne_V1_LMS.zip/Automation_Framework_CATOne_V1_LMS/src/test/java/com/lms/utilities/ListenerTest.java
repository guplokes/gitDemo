package com.lms.utilities;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.lms.testCases.baseClass;

public class ListenerTest extends baseClass implements ITestListener {

	public void onTestStart(ITestResult result) {
		System.out.println(result.getName()+" test case started");
	}

	public void onTestSuccess(ITestResult result) {
	    System.out.println("The name of the testcase passed is :"+result.getName());
	    extentRptflag=true;
	}

	public void onTestFailure(ITestResult result) {
		System.out.println("The name of the testcase failed is :"+result.getName());
		extentRptflag=false;		
	}

	public void onTestSkipped(ITestResult result) {
	    System.out.println("The name of the testcase Skipped is :"+result.getName());	
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
	}

	public void onStart(ITestContext context) {
		
	}

	public void onFinish(ITestContext context) {
	}

}
