package com.lms.utilities;
public class Log {
	

}
