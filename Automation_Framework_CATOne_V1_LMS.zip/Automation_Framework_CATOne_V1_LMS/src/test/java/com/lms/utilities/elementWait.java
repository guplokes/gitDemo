package com.lms.utilities;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.lms.testCases.baseClass;

public class elementWait extends baseClass {
	
	public void waitForElement(WebElement element, String ElementName) {
		WebDriverWait wait = new WebDriverWait(driver, objConfig.getElementWaitTime());
		wait.until(ExpectedConditions.visibilityOf(element));
		logger.info("Element "+ElementName+" is found successfully on the page.");
	}
	
	public void waitForElement(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, objConfig.getElementWaitTime());
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	
	public void applyImplicitWait() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Reporter.log("Implicit wait is getting applied.");
	}
}
