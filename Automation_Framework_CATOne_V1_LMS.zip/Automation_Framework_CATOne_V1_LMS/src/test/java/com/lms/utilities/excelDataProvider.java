package com.lms.utilities;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelDataProvider {
	XSSFWorkbook wb;
	DataFormatter formatter;
	private String[][] data;

	public excelDataProvider() {
		File src = new File("./TestData/TestData.xlsx");

		try {
			FileInputStream FIS = new FileInputStream(src);
			formatter = new DataFormatter();

			wb = new XSSFWorkbook(FIS);
		}

		catch (Exception e) {
			System.out.println("Could not read the excel file." + e.getMessage());
		}
	}

	public String getStringData(int SheetIndex, int row, int col) {
		return formatter.formatCellValue(wb.getSheetAt(SheetIndex).getRow(row).getCell(col));

		// return
		// wb.getSheetAt(SheetIndex).getRow(row).getCell(col).getStringCellValue();

		/*
		 * if(cell.getCellType()==CellType.STRING) data = cell.getStringCellValue();
		 * else if(cell.getCellType()==CellType.NUMERIC) data =
		 * String.valueOf(cell.getNumericCellValue());
		 */
	}

	public String getStringData(String sheetName, int Row, int Col) {
		// return wb.getSheet(sheetName).getRow(Row).getCell(Col).getStringCellValue();
		return formatter.formatCellValue(wb.getSheet(sheetName).getRow(Row).getCell(Col));
	}

	public double getNumericData(String sheetName, int row, int Col) {
		return wb.getSheet(sheetName).getRow(row).getCell(Col).getNumericCellValue();
	}

	public String[][] readExcelSheet(String sheetName) throws Exception {
		//FileInputStream fs = new FileInputStream(excelPath);
		//XSSFWorkbook workbook = new XSSFWorkbook(fs);
		XSSFSheet sheet = wb.getSheet(sheetName);

		int totalNoofRow = sheet.getLastRowNum();
		int totalnoOfCol = sheet.getRow(1).getPhysicalNumberOfCells();

		System.out.println("Total No of Row=" + totalNoofRow);

		System.out.println("Total No of Column=" + totalnoOfCol);

		System.out.println("");

		data = new String[totalNoofRow][totalnoOfCol];
		for (int row = 1; row <= totalNoofRow; row++) {
			for (int col = 0; col < totalnoOfCol; col++) {

				DataFormatter formatter = new DataFormatter();
				data[row - 1][col] = formatter.formatCellValue(sheet.getRow(row).getCell(col));
				System.out.print(formatter.formatCellValue(sheet.getRow(row).getCell(col)) + "\t");
			}
			System.out.println("");
		}
		return data;
	}
}
