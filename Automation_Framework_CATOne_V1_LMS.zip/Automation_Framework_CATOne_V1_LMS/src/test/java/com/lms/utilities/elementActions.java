package com.lms.utilities;

import java.awt.AWTException;
import java.text.ParseException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.SkipException;
import com.lms.testCases.baseClass;

public class elementActions extends baseClass {
	
	private WebDriver driver;

	public elementActions(WebDriver driver) {
		this.driver = driver;
	}

	public void enterData(WebElement element, String ElementName, String Value) {
		try {
			Thread.sleep(2000);
			moveToAnyElement(element, ElementName);
			wait.waitForElement(element,ElementName);
			element.sendKeys(Value);
			logger.info(ElementName + " is entered successfully.");
		} catch (Exception ex) {
			logger.fail(ElementName+" is not entered. \n"+ex);
		}
	}

	public void enterDataByJS(WebElement element, String ElementName, String Value) {
		try {
			Thread.sleep(2000);
			moveToAnyElement(element, ElementName);
			wait.waitForElement(element,ElementName);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
			Actions performAct = new Actions(driver).doubleClick(element);
			performAct.build().perform();
			performAct.sendKeys(element, Value).build().perform();
			logger.info(ElementName + " is entered successfully.");
		}

		catch (ElementNotVisibleException ex) {
			logger.fail(ElementName+" is not found on the web page \n"+ex);
		}

		catch (Exception ex) {
			logger.fail("There are some issue on the element.." + ex);
		}
	}

	public void clickElement(WebElement element, String ElementName) {
		try {
			Thread.sleep(2000);
		//	moveToAnyElement(element, ElementName);
			wait.waitForElement(element,ElementName);
			element.click();
			logger.info(ElementName + " is clicked.");
		}
		
		catch (ElementNotInteractableException ex) {
			logger.fail(ElementName + "Field is not interactable on the web page.\n"+ex);
		}

		catch (Exception ex) {
			logger.fail("There are some issue on the "+ElementName+" . \n"+ex);
			throw new SkipException("This test is skipped due to element " + ElementName + " is not clickable");
		}
	}
	
	public void enableRadioButton(WebElement element, String ElementName) {
		try {
			Thread.sleep(2000);
			wait.waitForElement(element,ElementName);
			element.click();
			logger.info(ElementName + " is enabled successfully.");
		}
		
		catch (ElementNotInteractableException ex) {
			logger.fail(ElementName + "Field is not interactable on the web page.\n"+ex);
		}

		catch (Exception ex) {
			logger.fail("There are some issue on the "+ElementName+" . \n"+ex);
			throw new SkipException("This test is skipped due to element " + ElementName + " is not clickable");
		}
	}
	
	public void disableRadioButton(WebElement element, String ElementName) {
		try {
			Thread.sleep(2000);
			wait.waitForElement(element,ElementName);
			element.click();
			logger.info(ElementName + " is disabled successfully.");
		}
		
		catch (ElementNotInteractableException ex) {
			logger.fail(ElementName + "Field is not interactable on the web page.\n"+ex);
		}

		catch (Exception ex) {
			logger.fail("There are some issue on the "+ElementName+" . \n"+ex);
			throw new SkipException("This test is skipped due to element " + ElementName + " is not clickable");
		}
	}
	
	
	public void clickTab(WebElement element, String ElementName) {
		try {
			Thread.sleep(5000);
			wait.waitForElement(element,ElementName);
			element.click();
			logger.info(ElementName + " is clicked.");
		}
		
		catch (ElementNotInteractableException ex) {
			logger.fail(ElementName + "Tab is not interactable on the web page.\n"+ex);
		}

		catch (Exception ex) {
			logger.fail("There are some issue on the "+ElementName+" Tab. \n"+ex);
			throw new SkipException("This test is skipped due to element " + ElementName + " is not clickable");
		}
	}
	
	public void moveToAnyElement(WebElement element,String ElementName) {
		try {
			Thread.sleep(2000);
			Actions performAct = new Actions(driver).doubleClick(element);
			performAct.build().perform();
		}
		catch (ElementNotVisibleException ex) {
			logger.fail("Test is interrupted because element " + ElementName + "is not visible on the web page... \n" + ex);
		}

		catch (Exception ex) {
			logger.fail("There are some issue on the element. That's why entire test is skipped. \n" + ex);
			throw new SkipException("This test is skipped due to element " + ElementName + " is not clickable");
		}
	}

	public void clickElementByJS(WebElement element, String ElementName) {
		try {
			Thread.sleep(2000);
			wait.waitForElement(element,ElementName);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
		}

		catch (ElementNotVisibleException ex) {
			logger.fail("Test is interrupted because element " + ElementName + "is not visible on the web page... \n" + ex);
		}

		catch (Exception ex) {
			logger.fail("There are some issue on the element. That's why entire test is skipped. \n" + ex);
			throw new SkipException("This test is skipped due to element " + ElementName + " is not clickable");
		}
	}

	public void selectDate(WebElement element, String ElementName) throws ParseException {
		String date = helper.getCurrentDateAndAddAMonth();
		try {
			wait.waitForElement(element,ElementName);
			element.click();
			String dateparam = "(//*[contains(@aria-label,'" + date + "')])" + "[1]";
			driver.findElement(By.xpath(dateparam)).click();
			logger.pass(ElementName + " selected successfully");
		} catch (ElementNotVisibleException ex) {
			logger.fail(ElementName + "Field is not found on the web page. \n"+ex);
		} catch (Exception ex) {
			logger.fail("Unable to select the " + ElementName+". \n"+ex);
			
		}
	}

	public void selectDDOptions(WebElement ddElement, String ddName, String ddOptions) {
		try {
			moveToAnyElement(ddElement, ddName);
			wait.waitForElement(ddElement,ddName);
		
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", ddElement); 	
			
			Actions performAct = new Actions(driver).doubleClick(ddElement);
			performAct.build().perform();
			performAct.sendKeys(ddElement, ddOptions).build().perform();  

			List<WebElement> element = driver.findElements(By.xpath("//div[text()='" + ddOptions + "']"));
			
			wait.waitForElement(element.get(0)); 			
			js.executeScript("arguments[0].click();", element.get(0));  
						
			logger.info(ddName+" is selected successfully.");
		} catch (ElementNotVisibleException ex) {
			logger.fail(ddName + "Field is not found on the web page. \n"+ex);
		} catch (Exception ex) {
			logger.fail("Unable to select the value of " + ddName +" \n"+ex);
		}
	}
	
	
	public void selectMultiSelectDDOptions(WebElement ddElement, String ddName, String ddOptions) throws AWTException, InterruptedException {
		try {
			String[] tempArr = ddOptions.split("[,]", 0);
			moveToAnyElement(ddElement, ddName);
			wait.waitForElement(ddElement,ddName);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", ddElement); 	
			for (String myStr : tempArr) {
				handleKeyboardEvent.enterText(myStr); 
				List<WebElement> element = driver.findElements(By.xpath("//*[contains(text(),'" + myStr + "')]"));
				js.executeScript("arguments[0].click();", element.get(0)); 	
				handleKeyboardEvent.removeText();
			}
			logger.info("All "+ddName+" are selected successfully.");
		}
		catch (ElementNotVisibleException ex) {
			logger.fail(ddName + "Field is not found on the web page. \n"+ex);
		} catch (Exception ex) {
			logger.fail("Unable to select the value of " + ddName +" \n"+ex);
		}
	}

	public void searchElement(String element, String elementName) {
		wait.waitForElement(driver.findElement(By.xpath("//*[text()='" + element + "']")));
		if (driver.findElement(By.xpath("//*[text()='" + element + "']")) != null) {
			logger.pass(elementName + " " + element + " is successfully search on the page.");
		} else {
			logger.fail("Account is not present on the page.");
		}
	}

	public void verifyWebPage(String expTitle, String pageName) {
		String actPageTitle = driver.getTitle();

		try {
			if (actPageTitle.equalsIgnoreCase(expTitle)) {
				logger.info("User is successfully navigated to " + pageName);
			} else {
				logger.info(pageName + " is not get open..");
			}
			Assert.assertTrue(actPageTitle.contains(expTitle));
		} catch (Exception ex) {
			logger.fail(ex);
		}
	}

	public void verifyMessage(WebElement element, String expMsg, String msgElement) {
		String actualMsg = element.getText();

		try {
			if (actualMsg.equalsIgnoreCase(expMsg)) {
				logger.pass(msgElement + "is successfull.");
			} else {
				logger.fail("Test case failed : " + msgElement + " is not happen.");
			}
			Assert.assertTrue(actualMsg.contains(expMsg));
		} catch (Exception ex) {
			logger.fail(ex);
		}
	}
}
