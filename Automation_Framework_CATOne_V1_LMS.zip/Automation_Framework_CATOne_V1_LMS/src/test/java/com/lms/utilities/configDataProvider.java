package com.lms.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class configDataProvider {
Properties Pro;
	
	public configDataProvider()
	{
		File src=new File("./Config/config.properties");
		
		try {
			FileInputStream fis=new FileInputStream(src);
			
			Pro=new Properties();
			
			Pro.load(fis);
		} catch (Exception e) {
			System.out.println("Not able to load config file "+e.getMessage());
			e.printStackTrace();
		} 
	}
	
	public String getDataFromConfig(String KeyToSearch)
	{
		return Pro.getProperty(KeyToSearch);
	}

	public String getBrowser()
	{
		return Pro.getProperty("Browser");
	}
	
	public String getURL() 
	{
		return Pro.getProperty("URL");
	}
	
	public long getElementWaitTime()
	{
		String waitTime=Pro.getProperty("waitTime");
		return Long.parseLong(waitTime);
	}
}
